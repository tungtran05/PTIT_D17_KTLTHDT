/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package preTest2.wordset;

import java.util.Scanner;


public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String str1 = sc.nextLine().trim().replaceAll("[ ]+", " "); String[] arr1 = str1.split(" ");
        String str2 = sc.nextLine().trim().replaceAll("[ ]+", " "); String[] arr2 = str2.split(" ");
        WordSet wordSet1 = new WordSet(arr1);
        WordSet wordSet2 = new WordSet(arr2);
        
        WordSet giao = wordSet1.giao(wordSet2);
        WordSet hop = wordSet1.hop(wordSet2);
        
        System.out.println(giao);
        System.out.println(hop);
    }
}

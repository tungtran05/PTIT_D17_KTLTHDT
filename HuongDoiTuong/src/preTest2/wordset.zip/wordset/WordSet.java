/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package preTest2.wordset;

import java.util.Set;
import java.util.TreeSet;

/**
 *
 * @author Xuan Toog
 */
public class WordSet{
    private TreeSet<String> set = new TreeSet<>();

    public WordSet() {
    }
    
    public WordSet(String[] a) {
        for(String str : a) {
            str = str.toLowerCase();
            set.add(str);
        }
    }
    
    public WordSet hop(WordSet other) {
        WordSet wordSet = new WordSet();
        wordSet.set.addAll(set);
        wordSet.set.addAll(other.set);
        
        return wordSet;
    }
    
    public WordSet giao(WordSet other) {
        WordSet wordSet = new WordSet();
        WordSet hop = hop(other);
        
        return wordSet;
    }

    @Override
    public String toString() {
        String r = "";
        for(String str : set) {
            r += str + " ";
        }
        
        return r.trim();
    }
    
    
}
